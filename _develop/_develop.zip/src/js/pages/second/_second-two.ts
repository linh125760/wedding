class SecondTwo {
  constructor() {
    console.log('Second page');
  }
}

window.addEventListener('DOMContentLoaded', () => {
  new SecondTwo();
});
