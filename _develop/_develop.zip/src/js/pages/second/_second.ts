class Second {
  constructor() {
    console.log('Second page');
  }
}


window.addEventListener('DOMContentLoaded', () => {
  new Second();
});