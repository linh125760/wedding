export default class Index {
  /**
   * Creates an instance of Index.
   */
  constructor() {
    console.log('index');
  }
}
