module.exports = {
  arrowParens: 'always',
  bracketSpacing: true,
  printWidth: 140,
  singleQuote: true,
  trailingComma: 'all'
};
